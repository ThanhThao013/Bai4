﻿namespace NT106_Lab02_23521466_23521038_23520863
{
    partial class Bai01
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Read_Button = new Button();
            TextBox = new RichTextBox();
            Write_Button = new Button();
            SuspendLayout();
            // 
            // Read_Button
            // 
            Read_Button.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Read_Button.Location = new Point(12, 13);
            Read_Button.Name = "Read_Button";
            Read_Button.Size = new Size(344, 79);
            Read_Button.TabIndex = 1;
            Read_Button.Text = "ĐỌC FILE";
            Read_Button.UseVisualStyleBackColor = true;
            Read_Button.Click += Read_Button_Click;
            // 
            // TextBox
            // 
            TextBox.Location = new Point(362, 12);
            TextBox.Name = "TextBox";
            TextBox.Size = new Size(484, 642);
            TextBox.TabIndex = 2;
            TextBox.Text = "";
            // 
            // Write_Button
            // 
            Write_Button.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Write_Button.Location = new Point(12, 117);
            Write_Button.Name = "Write_Button";
            Write_Button.Size = new Size(344, 79);
            Write_Button.TabIndex = 3;
            Write_Button.Text = "GHI FILE";
            Write_Button.UseVisualStyleBackColor = true;
            Write_Button.Click += Write_Button_Click;
            // 
            // Bai01
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(858, 666);
            Controls.Add(Write_Button);
            Controls.Add(TextBox);
            Controls.Add(Read_Button);
            Name = "Bai01";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion
        private Button Read_Button;
        private RichTextBox TextBox;
        private Button Write_Button;
    }
}
