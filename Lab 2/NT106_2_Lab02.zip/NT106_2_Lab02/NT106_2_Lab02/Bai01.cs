﻿using System;
namespace NT106_Lab02_23521466_23521038_23520863
{
    public partial class Bai01 : Form
    {
        string? path;
        bool isReadbuttonClicked = false;
        public Bai01()
        {
            InitializeComponent();
            TextBox.ReadOnly = true;
        }

        private void Read_Button_Click(object sender, EventArgs e)
        {
            TextBox.ReadOnly = false;
            TextBox.Clear();
            using (OpenFileDialog ofd = new OpenFileDialog())
            {

                ofd.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                ofd.Title = "Select a text file";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                     path = ofd.FileName;
                    if (path == null)
                    {
                        MessageBox.Show("First choose text file"); return;
                    }
                    else
                    { isReadbuttonClicked = true;
                        string? buffer;
                        using StreamReader sr = new StreamReader(path, System.Text.Encoding.UTF8);   
                        do
                        {
                            buffer = "";
                            buffer = sr.ReadLine();
                            TextBox.Text += buffer + '\n';
                        } while (buffer != null);
                        //readline sẽ ghi nhận dòng đầu tiên và đẩy con trỏ xuống dòng tiếp theo
                        sr.Close();
                    }
                     
                }
            }
        }
        private void Write_Button_Click(object sender, EventArgs e)
        {TextBox.ReadOnly = true;
          if( isReadbuttonClicked==false)
                // xử lý khi chưa có file nào được mở lên
            {
                MessageBox.Show("Click Read button first");
            }
          else
            {
    
                try
                {
                    string? AlPath = Path.GetDirectoryName(path?.ToString());
                    //Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
                    using (StreamWriter sw = new StreamWriter(AlPath + "\\output1.txt", false))
                    {
                        string? buffer;
                        //dấu chấm hỏi là để buffer có thể nhận luôn cả NULL
                        foreach (string line in TextBox.Lines)
                        {
                            buffer = line.ToUpper();
                            sw.WriteLine(buffer);
                        }

                    }
                    MessageBox.Show("UpperCase Successfully,Uppercased Form is Written at output1.txt");
                    TextBox.Clear();
                    using (OpenFileDialog ofd = new OpenFileDialog())
                    {
                        ofd.FileName = "output1.txt";
                        ofd.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                        ofd.Title = "Select a text file";
                        if (ofd.ShowDialog() == DialogResult.OK)
                        {
                            path = ofd.FileName;
                            if (path == null)
                            {
                                MessageBox.Show("First choose text file"); return;
                            }
                            else
                            {
                                isReadbuttonClicked = true;
                                string? buffer;
                                using StreamReader sr = new StreamReader(path, System.Text.Encoding.UTF8);
                                do
                                {
                                    buffer = "";
                                    buffer = sr.ReadLine();
                                    TextBox.Text += buffer + '\n';
                                } while (buffer != null);
                                //readline sẽ ghi nhận dòng đầu tiên và đẩy con trỏ xuống dòng tiếp theo
                                sr.Close();
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    // có thể bắt trường hợp khi 1 file text đang được mở thì có process khác thực hiện mở file
                }
            }
        }
    }
}
