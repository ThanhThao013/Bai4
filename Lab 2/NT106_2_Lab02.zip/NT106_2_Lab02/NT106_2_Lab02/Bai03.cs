﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace NT106_Lab02_23521466_23521038_23520863
{
    public partial class Bai03 : Form
    {
        string? path;
        bool isReadbuttonClicked = false;
        bool isFileSaved= false;
        public Bai03()
        {
            InitializeComponent();
            OpenBox.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenBox.Clear();
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            ofd.Title = "Select a text file";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                path = ofd.FileName;
                OpenPath.Text = Path.GetFileName(ofd.FileName);
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    MessageBox.Show("First choose text file"); return;
                }
                else
                {
                    isReadbuttonClicked = true;
                    string? buffer;
                    using StreamReader sr = new StreamReader(path, System.Text.Encoding.UTF8);
                    do
                    {
                        buffer = "";
                        buffer = sr.ReadLine();
                        OpenBox.Text += buffer + '\n';
                    } while (buffer != null);//readline sẽ ghi nhận dòng đầu tiên và đẩy con trỏ xuống dòng tiếp theo}
                }
                OpenBox.ReadOnly = false;
            }
            else return;
        }
        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (isReadbuttonClicked)
            {
                if (!isFileSaved) // Nếu file chưa được lưu, tiến hành lưu file ban đầu
                {
                    using (StreamWriter sw = new StreamWriter(path))
                    {
                        sw.Write(OpenBox.Text);
                    }
                    isFileSaved = true;
                }MessageBox.Show("Save clicked!");
            // Sau khi nhấn, đổi text nút thành "Create"
            SaveButton.Text = "Create";
            // Gỡ sự kiện Save_Click
            SaveButton.Click -= SaveButton_Click;
            // Thêm sự kiện Create_Click
            SaveButton.Click += btnCreate_Click;
            }
            else
            {
                MessageBox.Show("Please open a file first!");
            }
            
        }
        // Sự kiện mới cho chức năng Create
        private void btnCreate_Click(object sender, EventArgs e)
        {
            path = Path.GetDirectoryName(path) + "\\output1.txt";
            ResultBox.Clear();
            using (StreamWriter sw = new StreamWriter(path))
            {
                ResultPath.Text = Path.GetFileName(path)?.ToString();
                string[] lines = OpenBox.Text.Split('\n');
                foreach (string line in lines)
                {
                    if (string.IsNullOrEmpty(line)) { ResultBox.Text += "\n"; continue; }
                    if (string.IsNullOrWhiteSpace(line)) { ResultBox.Text += $"{line}"+"\n"; continue; }

                    // Giữ nguyên dấu chấm thập phân và chỉ thay thế các ký tự đặc biệt khác
                    string expression = line.Replace('–', '-');

                    if (IsValidExpression(expression))
                    {
                        double result = Math.Round(CalculateExpression(expression),2);
                        if (Math.Floor(result) == result) // Kiểm tra nếu số là nguyên
                        {
                            ResultBox.Text += $"{line} = {result}\n";
                        }
                        else // Nếu là số thập phân
                        {
                            ResultBox.Text += $"{line} = {result.ToString("G", CultureInfo.InvariantCulture)}\n";
                        }
                    }
                    else
                    {
                        ResultBox.Text += $"{line} = Invalid Expression\n";
                    }
                }
                ResultBox.ReadOnly = true;
            }
            MessageBox.Show("Create clicked!");
            // Sau khi nhấn, đổi text nút lại thành "Save"
            SaveButton.Text = "Save Input";
            // Gỡ sự kiện Create_Click
            SaveButton.Click -= btnCreate_Click;
            // Thêm lại sự kiện Save_Click
            SaveButton.Click += SaveButton_Click;
        }
        static bool IsValidExpression(string expression)
        {
            if (string.IsNullOrWhiteSpace(expression) || ContainsLetters(expression))
            {
                return false; // Biểu thức rỗng hoặc chứa chữ cái Latinh
            }
            int openParenthesisCount = 0;
            int closeParenthesisCount = 0;
            for (int i = 0; i < expression.Length; i++)
            {
                char currentChar = expression[i];
                // Kiểm tra dấu ngoặc
                if (currentChar == '(')
                {
                    openParenthesisCount++;
                    if (i + 1 < expression.Length && (IsOperator(expression[i + 1]) || expression[i + 1] == ')'))
                    {
                        return false;
                    }
                }
                else if (currentChar == ')')
                {
                    closeParenthesisCount++;
                    if (i - 1 >= 0 && (IsOperator(expression[i - 1]) || expression[i - 1] == '('))
                    {
                        return false;
                    }
                }
                // Kiểm tra các toán tử liền nhau
                else if (IsOperator(currentChar))
                {
                    if (i + 1 < expression.Length && IsOperator(expression[i + 1]))
                    {
                        return false;
                    }

                    if (i == 0 || i == expression.Length - 1)
                    {
                        return false;
                    }
                }
            }
            if (openParenthesisCount != closeParenthesisCount)
            {
                return false;
            }
            return true;
        }
        static bool ContainsLetters(string expression)
        {
            foreach (char c in expression)
            {
                if (char.IsLetter(c))
                {
                    return true;
                }
            }
            return false;
        }
        static bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '*' || c == '/';
        }
        static int Precedence(char op)
        {
            if (op == '+' || op == '-')
                return 1;
            if (op == '*' || op == '/')
                return 2;
            return 0;
        }
        static double ApplyOperation(double a, double b, char op)
        {
            switch (op)
            {
                case '+': return a + b;
                case '-': return a - b;
                case '*': return a * b;
                case '/': return a / b;
                default: throw new ArgumentException("Invalid operator");
            }
        }

        static List<string> InfixToPostfix(string expression)
        {
            Stack<char> stack = new Stack<char>();
            List<string> postfix = new List<string>();
            int i = 0;

            while (i < expression.Length)
            {
                if (char.IsDigit(expression[i]) || expression[i] == '.')
                {
                    string num = "";
                    while (i < expression.Length && (char.IsDigit(expression[i]) || expression[i] == '.'))
                    {
                        num += expression[i];
                        i++;
                    }
                    postfix.Add(num);
                    i--;
                }
                else if (expression[i] == '(')
                {
                    stack.Push(expression[i]);
                }
                else if (expression[i] == ')')
                {
                    while (stack.Count > 0 && stack.Peek() != '(')
                    {
                        postfix.Add(stack.Pop().ToString());
                    }
                    stack.Pop();
                }
                else if (IsOperator(expression[i]))
                {
                    while (stack.Count > 0 && Precedence(stack.Peek()) >= Precedence(expression[i]))
                    {
                        postfix.Add(stack.Pop().ToString());
                    }
                    stack.Push(expression[i]);
                }
                i++;
            }

            while (stack.Count > 0)
            {
                postfix.Add(stack.Pop().ToString());
            }

            return postfix;
        }

        static double EvaluatePostfix(List<string> postfix)
        {
            if (postfix == null || postfix.Count == 0) return double.NaN;

            Stack<double> stack = new Stack<double>();

            foreach (string token in postfix)
            {
                if (double.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out double num))
                {
                    stack.Push(num);
                }
                else
                {
                    if (stack.Count < 2)
                    {
                        return double.NaN;
                    }
                    double b = stack.Pop();
                    double a = stack.Pop();
                    double result = ApplyOperation(a, b, token[0]);
                    stack.Push(result);
                }
            }
            return stack.Count == 1 ? stack.Pop() : double.NaN;
        }
        static double CalculateExpression(string expression)
        {
            List<string> postfix = InfixToPostfix(expression);
            return EvaluatePostfix(postfix);
        }
    }
}
