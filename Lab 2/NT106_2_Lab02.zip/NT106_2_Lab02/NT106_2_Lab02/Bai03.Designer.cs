﻿namespace NT106_Lab02_23521466_23521038_23520863
{
    partial class Bai03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            OpenButton = new Button();
            OpenBox = new RichTextBox();
            ResultBox = new RichTextBox();
            OpenPath = new TextBox();
            ResultPath = new TextBox();
            SaveButton = new Button();
            SuspendLayout();
            // 
            // OpenButton
            // 
            OpenButton.Font = new Font("Segoe UI Emoji", 16F);
            OpenButton.Location = new Point(38, 202);
            OpenButton.Name = "OpenButton";
            OpenButton.Size = new Size(239, 107);
            OpenButton.TabIndex = 0;
            OpenButton.Text = "File Open";
            OpenButton.UseVisualStyleBackColor = true;
            OpenButton.Click += button1_Click;
            // 
            // OpenBox
            // 
            OpenBox.Location = new Point(309, 72);
            OpenBox.Name = "OpenBox";
            OpenBox.Size = new Size(465, 684);
            OpenBox.TabIndex = 2;
            OpenBox.Text = "";
            // 
            // ResultBox
            // 
            ResultBox.Location = new Point(780, 72);
            ResultBox.Name = "ResultBox";
            ResultBox.Size = new Size(465, 684);
            ResultBox.TabIndex = 3;
            ResultBox.Text = "";
            // 
            // OpenPath
            // 
            OpenPath.BorderStyle = BorderStyle.FixedSingle;
            OpenPath.Location = new Point(309, 39);
            OpenPath.Name = "OpenPath";
            OpenPath.ReadOnly = true;
            OpenPath.Size = new Size(465, 27);
            OpenPath.TabIndex = 4;
            OpenPath.TextAlign = HorizontalAlignment.Center;
            // 
            // ResultPath
            // 
            ResultPath.BorderStyle = BorderStyle.FixedSingle;
            ResultPath.Location = new Point(780, 39);
            ResultPath.Name = "ResultPath";
            ResultPath.ReadOnly = true;
            ResultPath.Size = new Size(465, 27);
            ResultPath.TabIndex = 5;
            ResultPath.TextAlign = HorizontalAlignment.Center;
            // 
            // SaveButton
            // 
            SaveButton.Font = new Font("Segoe UI Emoji", 16F);
            SaveButton.Location = new Point(38, 453);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(239, 107);
            SaveButton.TabIndex = 6;
            SaveButton.Text = "Save Input";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // Bai03
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1251, 756);
            Controls.Add(SaveButton);
            Controls.Add(ResultPath);
            Controls.Add(OpenPath);
            Controls.Add(ResultBox);
            Controls.Add(OpenBox);
            Controls.Add(OpenButton);
            Name = "Bai03";
            Text = "Bai03";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button OpenButton;
        private RichTextBox OpenBox;
        private RichTextBox ResultBox;
        private TextBox OpenPath;
        private TextBox ResultPath;
        private Button SaveButton;
    }
}